package com.datco.saludbateria

import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.BatteryManager
import kotlin.math.abs

data class BatteryInfo(
    val level: Int, val charging: Boolean, val status: String, val health: String,
    val tempC: Float, val volt: Float, val tech: String, val cycles: Int,
    val source: String, val currentMa: Int
) {
    companion object {
        fun read(ctx: Context): BatteryInfo =
            from(ctx, ctx.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED)))

        fun from(ctx: Context, i: Intent?): BatteryInfo {
            val lvl = i?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: -1
            val scale = i?.getIntExtra(BatteryManager.EXTRA_SCALE, 100) ?: 100
            val pct = if (lvl >= 0 && scale > 0) lvl * 100 / scale else 0
            val st = i?.getIntExtra(BatteryManager.EXTRA_STATUS, -1) ?: -1
            val charging = st == BatteryManager.BATTERY_STATUS_CHARGING ||
                st == BatteryManager.BATTERY_STATUS_FULL
            val statusTxt = when (st) {
                BatteryManager.BATTERY_STATUS_CHARGING -> "Cargando"
                BatteryManager.BATTERY_STATUS_FULL -> "Completa"
                BatteryManager.BATTERY_STATUS_DISCHARGING -> "Descargando"
                BatteryManager.BATTERY_STATUS_NOT_CHARGING -> "Sin cargar"
                else -> "Desconocido"
            }
            val health = when (i?.getIntExtra(BatteryManager.EXTRA_HEALTH, -1)) {
                BatteryManager.BATTERY_HEALTH_GOOD -> "Buena"
                BatteryManager.BATTERY_HEALTH_OVERHEAT -> "Sobrecalentada"
                BatteryManager.BATTERY_HEALTH_DEAD -> "Dañada"
                BatteryManager.BATTERY_HEALTH_OVER_VOLTAGE -> "Sobrevoltaje"
                BatteryManager.BATTERY_HEALTH_COLD -> "Fría"
                BatteryManager.BATTERY_HEALTH_UNSPECIFIED_FAILURE -> "Falla"
                else -> "Desconocida"
            }
            val source = when (i?.getIntExtra(BatteryManager.EXTRA_PLUGGED, 0)) {
                BatteryManager.BATTERY_PLUGGED_AC -> "Cargador"
                BatteryManager.BATTERY_PLUGGED_USB -> "USB"
                BatteryManager.BATTERY_PLUGGED_WIRELESS -> "Inalámbrica"
                else -> "Batería"
            }
            val bm = ctx.getSystemService(Context.BATTERY_SERVICE) as BatteryManager
            val raw = bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CURRENT_NOW)
            val ma = if (abs(raw) > 20000) raw / 1000 else raw
            return BatteryInfo(
                level = pct, charging = charging, status = statusTxt, health = health,
                tempC = (i?.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, 0) ?: 0) / 10f,
                volt = (i?.getIntExtra(BatteryManager.EXTRA_VOLTAGE, 0) ?: 0) / 1000f,
                tech = i?.getStringExtra(BatteryManager.EXTRA_TECHNOLOGY) ?: "—",
                cycles = i?.getIntExtra("android.os.extra.CYCLE_COUNT", -1) ?: -1,
                source = source, currentMa = ma
            )
        }
    }
}
