package com.datco.saludbateria

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import java.util.Calendar

enum class Periodo(val label: String) { DIA("Día"), SEMANA("Semana"), MES("Mes") }

data class Bar(val label: String, val value: Int)

class Db private constructor(ctx: Context) : SQLiteOpenHelper(ctx, "bateria.db", null, 1) {

    companion object {
        @Volatile private var inst: Db? = null
        fun get(ctx: Context): Db = inst ?: synchronized(this) {
            inst ?: Db(ctx.applicationContext).also { inst = it }
        }
    }

    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL("CREATE TABLE samples(ts INTEGER PRIMARY KEY, level INTEGER, charging INTEGER)")
    }

    override fun onUpgrade(db: SQLiteDatabase, o: Int, n: Int) {}

    fun add(level: Int, charging: Boolean) {
        val cv = ContentValues().apply {
            put("ts", System.currentTimeMillis())
            put("level", level)
            put("charging", if (charging) 1 else 0)
        }
        writableDatabase.insertWithOnConflict("samples", null, cv, SQLiteDatabase.CONFLICT_REPLACE)
    }

    fun purge() {
        val limit = System.currentTimeMillis() - 40L * 86_400_000L
        writableDatabase.delete("samples", "ts<?", arrayOf(limit.toString()))
    }

    /** Puntos de batería consumidos (bajada mientras no carga) por franja. */
    fun consumption(p: Periodo): List<Bar> {
        val cal = Calendar.getInstance()
        val n: Int
        val step: Long
        val start: Long
        if (p == Periodo.DIA) {
            cal.set(Calendar.MINUTE, 0); cal.set(Calendar.SECOND, 0); cal.set(Calendar.MILLISECOND, 0)
            n = 24; step = 3_600_000L; start = cal.timeInMillis - 23 * step
        } else {
            cal.set(Calendar.HOUR_OF_DAY, 0); cal.set(Calendar.MINUTE, 0)
            cal.set(Calendar.SECOND, 0); cal.set(Calendar.MILLISECOND, 0)
            n = if (p == Periodo.SEMANA) 7 else 30
            step = 86_400_000L
            start = cal.timeInMillis - (n - 1) * step
        }
        val vals = IntArray(n)
        var pts = 0L; var pl = -1; var pc = true
        readableDatabase.rawQuery(
            "SELECT ts,level,charging FROM samples WHERE ts>=? ORDER BY ts",
            arrayOf((start - 6 * 3_600_000L).toString())
        ).use { c ->
            while (c.moveToNext()) {
                val ts = c.getLong(0); val l = c.getInt(1); val ch = c.getInt(2) == 1
                if (pl >= 0 && !pc && !ch && ts >= start && ts - pts < 6 * 3_600_000L && pl > l) {
                    val idx = ((ts - start) / step).toInt()
                    if (idx in 0 until n) vals[idx] += pl - l
                }
                pts = ts; pl = l; pc = ch
            }
        }
        val dias = arrayOf("D", "L", "M", "X", "J", "V", "S")
        return List(n) { i ->
            cal.timeInMillis = start + i * step
            val label = when (p) {
                Periodo.DIA -> "%02d".format(cal.get(Calendar.HOUR_OF_DAY))
                Periodo.SEMANA -> dias[cal.get(Calendar.DAY_OF_WEEK) - 1]
                Periodo.MES -> cal.get(Calendar.DAY_OF_MONTH).toString()
            }
            Bar(label, vals[i])
        }
    }
}
