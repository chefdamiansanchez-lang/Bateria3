package com.datco.saludbateria

import android.app.AppOpsManager
import android.app.usage.UsageStatsManager
import android.content.Context
import android.content.Intent
import android.os.Process
import android.provider.Settings
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.graphics.drawable.toBitmap
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import java.util.Calendar

private val AppBg = Color(0xFF0F1512)
private val CardBg = Color(0xFF18211D)
private val Accent = Color(0xFF2ECC71)
private val Muted = Color(0xFF8FA39A)

@Composable
fun App() {
    var splash by remember { mutableStateOf(true) }
    MaterialTheme(colorScheme = darkColorScheme(primary = Accent, background = AppBg, surface = CardBg)) {
        if (splash) Splash { splash = false } else Main()
    }
}

// ---------- Splash DATCO ----------
@Composable
fun Splash(onDone: () -> Unit) {
    val a = remember { Animatable(0f) }
    LaunchedEffect(Unit) { a.animateTo(1f, tween(900)); delay(1300); onDone() }
    Box(Modifier.fillMaxSize().background(Color(0xFF1B2028)), contentAlignment = Alignment.Center) {
        Column(
            Modifier.alpha(a.value).scale(0.85f + 0.15f * a.value),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Box(
                Modifier.size(96.dp).clip(RoundedCornerShape(22.dp))
                    .background(Brush.linearGradient(listOf(Color(0xFF007BC7), Color(0xFF00D2FF)))),
                contentAlignment = Alignment.Center
            ) { Text("D", color = Color.White, fontSize = 56.sp, fontWeight = FontWeight.Bold) }
            Spacer(Modifier.height(20.dp))
            Text("DATCO", color = Color.White, fontSize = 34.sp, fontWeight = FontWeight.Bold, letterSpacing = 10.sp)
            Spacer(Modifier.height(8.dp))
            Text(
                "Desarrollo Avanzado de Tecnologías y Códigos Operativos",
                color = Color(0xFF8FA6B8), fontSize = 11.sp, textAlign = TextAlign.Center,
                modifier = Modifier.padding(horizontal = 32.dp)
            )
        }
        Text(
            "Diseño de apps... y algo más", color = Color(0xFF8FA6B8), fontSize = 12.sp,
            modifier = Modifier.align(Alignment.BottomCenter).padding(bottom = 36.dp).alpha(a.value)
        )
    }
}

// ---------- Estructura ----------
@Composable
fun Main() {
    var tab by remember { mutableIntStateOf(0) }
    Scaffold(
        containerColor = AppBg,
        bottomBar = {
            NavigationBar(containerColor = CardBg) {
                listOf("🔋" to "Batería", "📊" to "Consumo", "📱" to "Apps").forEachIndexed { i, (e, t) ->
                    NavigationBarItem(
                        selected = tab == i, onClick = { tab = i },
                        icon = { Text(e, fontSize = 20.sp) }, label = { Text(t) }
                    )
                }
            }
        }
    ) { pad ->
        Box(Modifier.padding(pad).fillMaxSize()) {
            when (tab) { 0 -> StatusScreen(); 1 -> ConsumptionScreen(); else -> AppsScreen() }
        }
    }
}

@Composable
fun Title(t: String) =
    Text(t, color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Bold)

@Composable
fun RangeTabs(sel: Periodo, onSel: (Periodo) -> Unit) {
    Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp)).background(CardBg).padding(4.dp)) {
        Periodo.values().forEach { r ->
            Box(
                Modifier.weight(1f).clip(RoundedCornerShape(10.dp))
                    .background(if (r == sel) Accent else Color.Transparent)
                    .clickable { onSel(r) }.padding(vertical = 10.dp),
                contentAlignment = Alignment.Center
            ) {
                Text(r.label, color = if (r == sel) AppBg else Color.White, fontWeight = FontWeight.SemiBold)
            }
        }
    }
}

// ---------- Pantalla Batería ----------
@Composable
fun StatusScreen() {
    val ctx = LocalContext.current
    var info by remember { mutableStateOf(BatteryInfo.read(ctx)) }
    LaunchedEffect(Unit) { while (true) { info = BatteryInfo.read(ctx); delay(3000) } }
    val prefs = remember { ctx.getSharedPreferences("prefs", 0) }
    var alertOn by remember { mutableStateOf(prefs.getBoolean("alert_on", true)) }
    var thr by remember { mutableFloatStateOf(prefs.getInt("alert_level", 80).toFloat()) }

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Title("Salud Batería")
        Spacer(Modifier.height(12.dp))
        Ring(info.level, info.charging)
        Spacer(Modifier.height(16.dp))
        val cyc = if (info.cycles >= 0) "${info.cycles}" else "No disponible"
        val rows = listOf(
            "Salud" to info.health, "Temperatura" to "%.1f °C".format(info.tempC),
            "Voltaje" to "%.2f V".format(info.volt), "Tecnología" to info.tech,
            "Ciclos de carga" to cyc, "Corriente" to "${info.currentMa} mA",
            "Estado" to info.status, "Fuente" to info.source
        )
        rows.chunked(2).forEach { r ->
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                r.forEach { (l, v) -> Stat(l, v, Modifier.weight(1f)) }
            }
            Spacer(Modifier.height(10.dp))
        }
        Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).background(CardBg).padding(14.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("Alerta de carga", color = Color.White, fontWeight = FontWeight.SemiBold, modifier = Modifier.weight(1f))
                Switch(
                    checked = alertOn,
                    onCheckedChange = { alertOn = it; prefs.edit().putBoolean("alert_on", it).apply() },
                    colors = SwitchDefaults.colors(checkedTrackColor = Accent)
                )
            }
            if (alertOn) {
                Text("Avisar al llegar al ${thr.toInt()} %", color = Muted, fontSize = 13.sp)
                Slider(
                    value = thr, onValueChange = { thr = it }, valueRange = 50f..100f,
                    onValueChangeFinished = { prefs.edit().putInt("alert_level", thr.toInt()).apply() },
                    colors = SliderDefaults.colors(thumbColor = Accent, activeTrackColor = Accent)
                )
            }
        }
    }
}

@Composable
fun Ring(level: Int, charging: Boolean) {
    val color = when { level <= 15 -> Color(0xFFE74C3C); level <= 30 -> Color(0xFFF39C12); else -> Accent }
    Box(Modifier.size(220.dp), contentAlignment = Alignment.Center) {
        Canvas(Modifier.fillMaxSize()) {
            val sw = 22.dp.toPx()
            val tl = Offset(sw / 2, sw / 2)
            val sz = Size(size.width - sw, size.height - sw)
            drawArc(Color(0xFF24312B), -90f, 360f, false, tl, sz, style = Stroke(sw))
            drawArc(color, -90f, 360f * level / 100f, false, tl, sz, style = Stroke(sw, cap = StrokeCap.Round))
        }
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text("$level%", color = Color.White, fontSize = 48.sp, fontWeight = FontWeight.Bold)
            Text(if (charging) "⚡ Cargando" else "En uso", color = Muted, fontSize = 14.sp)
        }
    }
}

@Composable
fun Stat(label: String, value: String, m: Modifier) {
    Column(m.clip(RoundedCornerShape(16.dp)).background(CardBg).padding(14.dp)) {
        Text(label, color = Muted, fontSize = 12.sp)
        Text(value, color = Color.White, fontSize = 17.sp, fontWeight = FontWeight.SemiBold)
    }
}

// ---------- Pantalla Consumo ----------
@Composable
fun ConsumptionScreen() {
    val ctx = LocalContext.current
    val db = remember { Db.get(ctx) }
    var p by remember { mutableStateOf(Periodo.DIA) }
    var bars by remember { mutableStateOf(listOf<Bar>()) }
    LaunchedEffect(p) {
        while (true) {
            bars = withContext(Dispatchers.IO) { db.consumption(p) }
            delay(10_000)
        }
    }
    val total = bars.sumOf { it.value }
    val active = bars.count { it.value > 0 }.coerceAtLeast(1)
    val unidad = if (p == Periodo.DIA) "hora" else "día"

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp)) {
        Title("Consumo de batería")
        Spacer(Modifier.height(12.dp))
        RangeTabs(p) { p = it }
        Spacer(Modifier.height(14.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            Stat("Consumido", "$total %", Modifier.weight(1f))
            Stat("Promedio por $unidad", "${total / active} %", Modifier.weight(1f))
        }
        Spacer(Modifier.height(14.dp))
        Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).background(CardBg).padding(12.dp)) {
            BarChart(bars)
        }
        Spacer(Modifier.height(10.dp))
        Text(
            if (total == 0) "Todavía no hay datos. Dejá la app instalada y usá el teléfono unas horas."
            else "Se mide la batería que baja mientras no está cargando, desde que instalaste la app.",
            color = Muted, fontSize = 12.sp
        )
    }
}

@Composable
fun BarChart(bars: List<Bar>) {
    val maxV = (bars.maxOfOrNull { it.value } ?: 0).coerceAtLeast(1)
    Canvas(Modifier.fillMaxWidth().height(210.dp)) {
        val n = bars.size.coerceAtLeast(1)
        val slot = size.width / n
        val bw = slot * 0.62f
        val labelH = 22.dp.toPx()
        val chartH = size.height - labelH
        val every = if (n > 12) 3 else 1
        val paint = android.graphics.Paint().apply {
            color = android.graphics.Color.parseColor("#8FA39A")
            textSize = 10.sp.toPx(); textAlign = android.graphics.Paint.Align.CENTER; isAntiAlias = true
        }
        val vPaint = android.graphics.Paint(paint).apply { color = android.graphics.Color.WHITE }
        bars.forEachIndexed { i, b ->
            val h = (chartH - 16.dp.toPx()) * b.value / maxV
            val x = i * slot + (slot - bw) / 2
            drawRoundRect(
                Accent, Offset(x, chartH - h), Size(bw, h.coerceAtLeast(2f)), CornerRadius(6f, 6f)
            )
            if (n <= 7 && b.value > 0)
                drawContext.canvas.nativeCanvas.drawText("${b.value}%", i * slot + slot / 2, chartH - h - 6f, vPaint)
            if (i % every == 0)
                drawContext.canvas.nativeCanvas.drawText(b.label, i * slot + slot / 2, size.height - 4f, paint)
        }
    }
}

// ---------- Pantalla Apps ----------
data class AppUse(val name: String, val millis: Long, val icon: ImageBitmap)

fun hasUsageAccess(ctx: Context): Boolean {
    val ops = ctx.getSystemService(Context.APP_OPS_SERVICE) as AppOpsManager
    @Suppress("DEPRECATION")
    val mode = ops.checkOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS, Process.myUid(), ctx.packageName)
    return mode == AppOpsManager.MODE_ALLOWED
}

fun topApps(ctx: Context, p: Periodo): List<AppUse> {
    val usm = ctx.getSystemService(Context.USAGE_STATS_SERVICE) as UsageStatsManager
    val cal = Calendar.getInstance()
    val end = cal.timeInMillis
    val start = when (p) {
        Periodo.DIA -> {
            cal.set(Calendar.HOUR_OF_DAY, 0); cal.set(Calendar.MINUTE, 0)
            cal.set(Calendar.SECOND, 0); cal.set(Calendar.MILLISECOND, 0); cal.timeInMillis
        }
        Periodo.SEMANA -> end - 7 * 86_400_000L
        Periodo.MES -> end - 30 * 86_400_000L
    }
    val pm = ctx.packageManager
    return usm.queryAndAggregateUsageStats(start, end).values
        .filter { it.totalTimeInForeground > 60_000 && pm.getLaunchIntentForPackage(it.packageName) != null }
        .sortedByDescending { it.totalTimeInForeground }
        .take(15)
        .mapNotNull { u ->
            try {
                val ai = pm.getApplicationInfo(u.packageName, 0)
                AppUse(
                    pm.getApplicationLabel(ai).toString(), u.totalTimeInForeground,
                    pm.getApplicationIcon(ai).toBitmap(96, 96).asImageBitmap()
                )
            } catch (_: Exception) { null }
        }
}

fun fmt(ms: Long): String {
    val m = ms / 60_000
    return if (m >= 60) "${m / 60} h ${m % 60} min" else "$m min"
}

@Composable
fun AppsScreen() {
    val ctx = LocalContext.current
    var p by remember { mutableStateOf(Periodo.DIA) }
    var allowed by remember { mutableStateOf(hasUsageAccess(ctx)) }
    var apps by remember { mutableStateOf(listOf<AppUse>()) }
    LaunchedEffect(p) {
        while (true) {
            allowed = hasUsageAccess(ctx)
            apps = if (allowed) withContext(Dispatchers.IO) { topApps(ctx, p) } else emptyList()
            delay(5_000)
        }
    }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp)) {
        Title("Apps más usadas")
        Spacer(Modifier.height(12.dp))
        RangeTabs(p) { p = it }
        Spacer(Modifier.height(14.dp))
        if (!allowed) {
            Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).background(CardBg).padding(16.dp)) {
                Text("Hace falta el permiso de acceso al uso para ver qué apps usás más.", color = Color.White)
                Spacer(Modifier.height(10.dp))
                Button(
                    onClick = { ctx.startActivity(Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) },
                    colors = ButtonDefaults.buttonColors(containerColor = Accent, contentColor = AppBg)
                ) { Text("Dar permiso") }
            }
        } else {
            val maxMs = (apps.maxOfOrNull { it.millis } ?: 1L).coerceAtLeast(1L)
            apps.forEachIndexed { i, a ->
                Row(
                    Modifier.fillMaxWidth().padding(vertical = 5.dp).clip(RoundedCornerShape(14.dp))
                        .background(CardBg).padding(12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("${i + 1}", color = Muted, modifier = Modifier.width(22.dp))
                    Image(a.icon, null, Modifier.size(40.dp))
                    Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)) {
                        Row {
                            Text(a.name, color = Color.White, fontWeight = FontWeight.SemiBold, maxLines = 1, modifier = Modifier.weight(1f))
                            Text(fmt(a.millis), color = Muted, fontSize = 13.sp)
                        }
                        Spacer(Modifier.height(6.dp))
                        Box(Modifier.fillMaxWidth().height(6.dp).clip(RoundedCornerShape(3.dp)).background(Color(0xFF24312B))) {
                            Box(Modifier.fillMaxWidth(a.millis.toFloat() / maxMs).fillMaxHeight().background(Accent))
                        }
                    }
                }
            }
            if (apps.isEmpty()) Text("Sin datos todavía para este período.", color = Muted)
            Spacer(Modifier.height(8.dp))
            Text(
                "Android no deja a las apps ver el % de batería por aplicación, por eso se muestra el tiempo de uso.",
                color = Muted, fontSize = 12.sp
            )
        }
    }
}
