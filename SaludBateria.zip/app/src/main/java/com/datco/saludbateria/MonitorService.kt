package com.datco.saludbateria

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder

class MonitorService : Service() {
    private var last = -1
    private var lastCh = false
    private var alerted = false

    private val rx = object : BroadcastReceiver() {
        override fun onReceive(c: Context, i: Intent) {
            val b = BatteryInfo.from(c, i)
            if (b.level != last || b.charging != lastCh) {
                last = b.level; lastCh = b.charging
                Db.get(c).add(b.level, b.charging)
            }
            val p = c.getSharedPreferences("prefs", 0)
            val thr = p.getInt("alert_level", 80)
            if (p.getBoolean("alert_on", true) && b.charging && b.level >= thr) {
                if (!alerted) { alerted = true; notifyAlert(c, b.level, thr) }
            } else if (!b.charging || b.level < thr) {
                alerted = false
            }
        }
    }

    override fun onCreate() {
        super.onCreate()
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("monitor", "Monitoreo", NotificationManager.IMPORTANCE_LOW))
        nm.createNotificationChannel(NotificationChannel("alert", "Alerta de carga", NotificationManager.IMPORTANCE_HIGH))
        val n = Notification.Builder(this, "monitor")
            .setSmallIcon(android.R.drawable.ic_lock_idle_charging)
            .setContentTitle("Salud Batería")
            .setContentText("Monitoreando la batería")
            .setContentIntent(openApp())
            .setOngoing(true)
            .build()
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else {
            startForeground(1, n)
        }
        Db.get(this).purge()
        registerReceiver(rx, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
    }

    private fun openApp(): PendingIntent =
        PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)

    private fun notifyAlert(c: Context, lvl: Int, thr: Int) {
        val n = Notification.Builder(c, "alert")
            .setSmallIcon(android.R.drawable.ic_lock_idle_charging)
            .setContentTitle("Batería al $lvl %")
            .setContentText("Llegó al $thr %. Podés desconectar el cargador.")
            .setContentIntent(openApp())
            .setAutoCancel(true)
            .build()
        getSystemService(NotificationManager::class.java).notify(2, n)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int) = START_STICKY

    override fun onDestroy() {
        try { unregisterReceiver(rx) } catch (_: Exception) {}
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
